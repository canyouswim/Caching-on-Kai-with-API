Allows basic geocaching functionality from the KaiOS platform.

**Change Log:**

New for v3.0.0
* Major rewrite of the entire app to use the official Geocaching.com API

